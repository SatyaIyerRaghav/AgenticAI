### GenAI Based RCM Front Office Operations: Patient Doctor Interactions Through Agentic AI — End-to-End Guide

This guide explains, in detail, how the AI Medical Scribe system ingests audio recordings, structures the data, runs an agentic review workflow, and produces a complete Patient–Doctor interaction summary and documentation.

Use this as your single source of truth for setup, configuration, execution, flow internals, troubleshooting, and operations.

----------------------------------------------------------------------------------------------------------------
1) System Overview
-----------------------------------------------------------------------------------------------------------------

**Goal**: Automate clinical documentation and coding from doctor–patient conversations using an Agentic AI pipeline. The system converts raw audio into structured clinical notes and billing-ready data, reducing manual effort and improving accuracy.

**Core Frameworks** :
- LangGraph → Orchestrates the full pipeline as a state machine operating on ScribeState.
- CrewAI → Encapsulates LLM-powered agents responsible for transcription, note generation, coding, validation, and documentation.

**Key Outputs** :
- One structured JSON per consultation under /outputs/, containing:
    -Patient and encounter data
    -SOAP notes (Subjective, Objective, Assessment, Plan)
    -ICD/CPT codes
    -Audit and compliance summary
    -Logs under /Logs/Modules tracking workflow execution and agent performance.

----------------------------------------------------------------------------------------------------------------
2) Repository Components
----------------------------------------------------------------------------------------------------------------

- `src/run.py`: CLI entrypoint for end-to-end processing of single audio file. Produces raw transcript under `<audiofile name>.<txt>`.
- `src/cli_ocr.py`: Run ingest agent to produce structured JSON per new schema.
- `src/graph.py`: LangGraph nodes, transitions, and `build_app()` to compile the graph.
- `src/agents.py`: Lists of Agents, Tasks, Crew created
- `src/agent_builder.py`: use CrewAI agents and tasks from agents.py , add all functionalities that each agent will perform and finally saving the final json as structured PDF under src/output and audio to text transcript under src/transcript.
- `src/models.py`: Pydantic models for `VoiceToTextData`, `ClinicalUnderstandingData`, `RCMCodingData`, `FrontOfficeData`,`Guidelines`,`PipelineState`,,`AgentState`.
- `src/config.py`: YAML + env loader and env application.
- `src/logger_setup.py`: File logging (flow/error) and stdout/stderr tee-ing.
- `src/config_loader.py` : using Config settings for creating Streamlit applications.
- `src/utils.py` : use Whisper lib locally to transcribe audio to raw text.
- `src/Voice_to_text.py` : Build logic for transcribing audio to text format.

----------------------------------------------------------------------------------------------------------------
3) Data Model (pydantic)
----------------------------------------------------------------------------------------------------------------

1. **PatientData**

    - patient_id: string
    - demographics: dict (name, age, gender, DOB, contact, etc.)
    - insurance_status: dict with primary / secondary plans
    - network_status: optional string (in-network / out-of-network)
    - diagnoses: list of strings (ICD-10 or clinical terms)
    - procedures: list of strings (CPT or procedure codes)
    - tests: dict of test results or lab summaries
    - urgency: optional string (urgent or routine)

2. **TranscriptionData**

    - transcript: full conversation text from audio
    - confidence: float (speech-to-text accuracy)
    - timestamps: list of {word, start, end} dicts

3. **ClinicalNotes**

    - subjective: patient-reported symptoms
    - objective: clinician observations or vitals
    - assessment: diagnostic reasoning summary
    - plan: treatment or follow-up recommendations
    - summary: condensed visit overview
    - entities: extracted key terms (medications, conditions, etc.)

4. **CodingData**

    - icd10: list of ICD-10 diagnosis codes
    - cpt: list of CPT procedure codes
    - modifiers: list of billing modifiers
    - justification: text explanation for coding
    - coder_notes: optional internal review notes

5. **ComplianceData**

    - phi_redacted_text: PHI-safe version of transcript
    - hipaa_audit_passed: bool
    - violations: list of flagged compliance issues
    - audit_notes: optional text

6. **ScribeState**

    - source_audio: path or URL to input audio file
    - patient_data: PatientData
    - transcription: TranscriptionData
    - clinical_notes: ClinicalNotes
    - coding: CodingData
    - compliance: ComplianceData
    - structured_output: dict with formatted EHR-ready output
    - logs: list of pipeline-level logs and status updates

-----------------------------------------------------------------------------------------------------------------
4) Configuration
-----------------------------------------------------------------------------------------------------------------

The app uses both `config.yaml` and environment variables. At startup, `config.yaml` is loaded and mapped into env vars via `apply_env_from_config`.

- `config.yaml` sections:
  - `aws`: `region`, plus optional credentials if using Bedrock. Prefer environment variables or local-only config files for secrets.
  - `llm`: `provider` (`openai`|`groq`|`bedrock`|`huggingface`), `model`, and optional `api_key`/inference profile IDs.
  - `generation`: `temperature`.
 

Recognized env vars (examples):

- LLMs: `OPENAI_API_KEY`, `GROQ_API_KEY`, `HUGGINGFACEHUB_API_TOKEN`, `MODEL_NAME`, `MODEL_TEMPERATURE`
- Bedrock: `AWS_REGION`/`AWS_DEFAULT_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, optional `AWS_SESSION_TOKEN`, `BEDROCK_MODEL_ID`, `BEDROCK_INFERENCE_PROFILE_ID`/`ARN`


Security note: never commit real credentials. Use a local `.env` or untracked `config.yaml`. Rotate any credentials that were ever committed.

-----------------------------------------------------------------------------------------------------------------
5) Prerequisites and Install
-----------------------------------------------------------------------------------------------------------------
- Python 3.10+
Install Python dependencies:

```bash
pip install -r requirements.txt
```
-----------------------------------------------------------------------------------------------------------------
6) Running the End-to-End Pipeline
-----------------------------------------------------------------------------------------------------------------
Run on one audio file [Patient- Doctor Conversation]:

```bash
python -m src.run audio_recordings\audio_recordings\Audio_Recordings\CAR0001.mp3
```

Outputs:

- Saved PDF under `Outputs/` named `<Clinical_Document_<datetime>.pdf` with :
  
    - `SUBJECTIVE Section`- having `Past Medical History,Social History ,Family History` details
    - `OBJECTIVE Section ` - having `Required Elements for Documentation` details
    - `ASSESSMENT Section`
    - `PLAN Section` - having `Diagnostic Studies,Consultations,Authorization/Insurance` details
    - `COMPLIANCE NOTES Section` 
    - `BILLING AND CODING SUMMARY Section `- having `CPT Codes,ICD-10 Codes` details

Logs:

- `Logs/flow_<timestamp>.log` (INFO+) and `Logs/error_<timestamp>.log` (ERROR+)
- `Logs/Modules`- `store agent_builder.log` with all detailed steps of each agent processing.

-----------------------------------------------------------------------------------------------------------------
7) Execution Flow 
-----------------------------------------------------------------------------------------------------------------

The LangGraph app in `src/graph.py` compiles the following nodes into a Sequential AI medical documentation flow:

1. **voice_to_text_task**

    *Input: PipelineState(source_audio)
    *Actions:
      -Converts raw clinical audio (patient–provider conversation) into transcript text.
      -Extracts timestamps and word-level confidence using an ASR (Automatic Speech Recognition) model.
      -Populates raw transcript and save under transcript folder 
    *Output: transcript, state.logs

2. **clinical_understanding_task**

    *Input: state.transcript
    *Actions:
      -Calls CrewAI clinical_understanding_agent to interpret the transcript into structured context.
      -Extracts symptoms, conditions, diagnoses, assessment, and plan (SOAP-style).
      -Generates ClinicalUnderstandingData with reasoning and confidence scores.
    *Output: state.clinical_understanding, state.logs

3. **rcm_coding_task**

    *Input: state.clinical_understanding
    *Actions:
      -Runs CrewAI rcm_coding_agent to assign medical codes.
      -Maps findings to ICD-10 (diagnosis) and CPT (procedure) codes with appropriate modifiers.
      -Adds coder justification and confidence metadata.
    *Output: state.rcm_coding, state.logs.

4. **front_office_task**

    *Input: state.rcm_coding
    *Actions:
      -Checks patient eligibility, payer name, and plan details from front-office context.
      -Verifies if prior authorization is required or already present.
      -Generates workflow task list and turnaround time estimation.
    *Output: state.front_office, state.logs.

5. **compliance_quality_task**

    *Input: state.front_office
    *Actions:
      -Performs PHI redaction and HIPAA compliance validation.
      -Runs quality checks on completeness, correctness, and confidentiality.
      -Updates phi_redacted_text, hipaa_audit_passed, and adds findings.
    *Output: state.compliance_findings, state.logs.

6. **document_task**

    *Input: All accumulated state data (voice_to_text, clinical_understanding, rcm_coding, front_office, compliance_quality).
    *Actions:
      -Synthesizes structured EHR-ready documentation.
      -Generates formatted output (JSON/PDF) containing patient summary, codes, compliance report, and billing data.
      -Finalizes state.structured_output and submission status.
    *Output: state.structured_output, state.ehr_submission_status, state.logs.

**Compilation:**
The pipeline is wired as:
`START → voice_to_text_task → clinical_understanding_task → rcm_coding_task → front_office_task → compliance_quality_task → document_task → END.`

-----------------------------------------------------------------------------------------------------------------
8) Extensibility
-----------------------------------------------------------------------------------------------------------------
- Add a new node:
  - Create a function `node_<name>(state: PAState, tasks)` in `src/graph.py`.
  - Register with `graph.add_node(...)` and add edges.
- Add/modify a CrewAI task:
  - Update `build_tasks_with_llm` in `src/agent_builder.py`. Each task can specify `output_pydantic` for structured validation.

-----------------------------------------------------------------------------------------------------------------
9) Operational Runbook
-----------------------------------------------------------------------------------------------------------------
**Logs:** Flow and error logs per run under /Logs/. stdout/stderr tee’d to loggers.

**Idempotency:** Re-runs do not overwrite outputs; timestamped filenames like Clinical_Summary_2025-10-31_09-42-15.pdf.

**Performance tips:** Chunk audio, use smaller ASR models for early tasks, larger for document_task.

**Concurrency:** CLI is serial; parallel runs need threads/process pools respecting LLM limits.

**Failure handling:** Minimal transcript or partial state fallback for LLM failures; JSON normalization for compliance/documentation nodes.

-----------------------------------------------------------------------------------------------------------------
10) Troubleshooting
-----------------------------------------------------------------------------------------------------------------

-Audio transcription fails: Check audio path, format, FFmpeg, and ASR model.
-No LLM provider: Ensure dependencies and API keys.
-CrewAI non-JSON: Trim first {...}; inspect logs.
-Missing coding output: Inspect intermediate logs; re-run nodes if needed.
-Large audio files: Chunk or stream processing; smaller ASR models.
-PDF/report errors: Ensure output dir exists and text is Unicode-safe.

-----------------------------------------------------------------------------------------------------------------
11) Security & Compliance
-----------------------------------------------------------------------------------------------------------------

-Credentials: Use env-managed secrets; scoped IAM roles preferred.
-Data & Logging: Avoid PHI in logs; enforce encryption, rotation, and retention policies.
-Compliance: Ensure HIPAA and local regulations compliance; audit compliance_findings.

-----------------------------------------------------------------------------------------------------------------
12) Known Limitations
-----------------------------------------------------------------------------------------------------------------

-Accuracy: ASR/LLM quality impacts transcription and documentation.
-Coding & Interpretation: LLM-assisted mappings may miss edge cases.
-Document Generation: Narrative outputs are probabilistic; production requires rule validation.
-Dependencies: Network/API availability affects processing speed and reliability.

-----------------------------------------------------------------------------------------------------------------
13) Quickstart Checklist
-----------------------------------------------------------------------------------------------------------------

1. Install Python deps: `pip install -r requirements.txt`
2. Set LLM provider credentials and model.
3. Run: `python -m src.run <audio-file path>`
4. Review `Outputs/<pdf>.pdf` and `Logs/`.

-----------------------------------------------------------------------------------------------------------------
14)Streamlit Application
-----------------------------------------------------------------------------------------------------------------
**Purpose:**
-Provides a web-based interface to upload patient–doctor audio recordings and run the AI Medical Scribe pipeline.
-Displays real-time status, transcripts, structured clinical notes, coding suggestions, and compliance checks.

**Setup:**
Install dependencies: `pip install streamlit`

**Launch the app:** `streamlit run app.py`

**Workflow:**
-Upload Audio: .wav, .mp3, or .m4a file via the uploader.
-Run Pipeline: Press “Run AI Scribe Pipeline” to invoke the LangGraph workflow.

**View Outputs:**
-Transcription of the consultation.
-Structured SOAP notes (subjective, objective, assessment, plan).
-ICD-10 / CPT coding suggestions.
-Compliance & HIPAA audit results.
-Download: Export results as JSON or PDF files for EHR integration or record keeping.

**File Management:**
-Uploaded audio is saved with a timestamp to avoid overwriting previous sessions:
temp_audio/<filename>_YYYY-MM-DD_HH-MM-SS.wav.
-Outputs are written to /Outputs/ with timestamped filenames for reproducibility.

**Logging:**
-All pipeline steps are logged in /Logs/.
-Real-time progress is displayed in the Streamlit interface for transparency.

**Extensibility:**
-Streamlit app can be extended to handle batch audio uploads, parallel processing, or integration with cloud storage.
-Supports swapping ASR/LLM models dynamically for performance or accuracy tuning.

